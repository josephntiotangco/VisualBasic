=============================trsApp ReadMe==============================

Terms and Conditions:
> Additional requirements not stated / declared in the initial 
excel vba app will incur payment as this is only a free app.

- CHI



=============================trsApp ReadMe==============================